Thank you for purchasing this 3d model on Turbosquid.
For questions, requests, personalized orders, model conversions, complaints
write to:

duchampmodels@gmail.com

or visit:

http://xoomer.virgilio.it/www.duchampmodels.com  


Duchamp Models.

--------------------------------------------------
